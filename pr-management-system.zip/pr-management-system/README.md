# Pressly — PR / Influencer Management Platform

A converted, file-based version of the original single-file React
component. The **main file to run is `app.py`** (Python/Flask); it
serves a plain HTML/CSS/JS front end (no build step, no npm needed).

## Project structure

```
pr-management-system/
├── app.py                     # ▶ RUN THIS — Flask server entry point
├── requirements.txt
├── templates/
│   └── index.html             # HTML shell, loads CSS + JS in order
└── static/
    ├── css/
    │   └── style.css          # colors, fonts, global styles
    └── js/
        ├── icons.js           # SVG icon set
        ├── ui.js               # COLORS, Badge/Btn/StatCard/Avatar/MiniChart
        ├── layout.js           # Sidebar + Topbar
        ├── landing.js          # Landing page
        ├── auth.js             # Login / Register screens
        ├── brand_pages.js      # Brand dashboard, campaigns, discovery, analytics
        ├── influencer_pages.js # Influencer dashboard, opportunities, payments, messages
        └── app.js              # App state, router/render loop, click delegation
```

## How it works

- `app.py` starts a Flask dev server and renders `templates/index.html`.
- `index.html` loads the CSS and then each JS file in dependency order.
- Every page is a plain JS function that returns an HTML string
  (e.g. `BrandDashboard()`, `LandingPage()`), mirroring the original
  React components one-to-one.
- `app.js` holds a single `appState` object (`screen`, `role`, `page`)
  and a `render()` function that rebuilds `#root` — the same idea as
  React's `useState` + re-render, just without a framework.
- Clicks are handled with **one delegated listener** in `app.js`.
  Elements declare `data-action="..."` (and optionally
  `data-value="..."`) instead of inline `onClick` handlers, e.g.:
  `<button data-action="setPage" data-value="campaigns">`.

## Run it

```bash
cd pr-management-system
pip install -r requirements.txt
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.
