"""
Pressly - PR / Influencer Management Platform
================================================
Main Python entry point. Run this file to start the app:

    python app.py

Then open http://127.0.0.1:5000 in your browser.

This is a Flask app that serves a single-page front end built with
plain HTML / CSS / JavaScript (no build step required). All the
front-end logic lives in static/js/*.js and mirrors the original
React component structure (Sidebar, Topbar, Brand pages, Influencer
pages, Landing page, Auth page) but written as vanilla JS render
functions with a tiny hand-rolled router + event delegation system.
"""

from flask import Flask, render_template

app = Flask(__name__)


@app.route("/")
def index():
    """Serve the single-page app shell."""
    return render_template("index.html")


if __name__ == "__main__":
    # debug=True gives auto-reload while you edit the JS/CSS files
    app.run(debug=True, host="127.0.0.1", port=5000)
