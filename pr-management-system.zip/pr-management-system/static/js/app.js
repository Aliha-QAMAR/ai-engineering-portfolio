// ======================== MAIN APP ========================
// A tiny hand-rolled "framework": one state object, one render()
// function that rebuilds the #root innerHTML, and a single delegated
// click listener that maps data-action/data-value attributes to state
// changes (mirrors the useState + component-tree structure of the
// original React version).

const appState = {
  screen: "landing", // landing | auth | brand | influencer
  role: null,
  page: "dashboard",
};

const PAGE_TITLES = {
  dashboard: "Dashboard",
  campaigns: "Campaigns",
  discovery: "Influencer Discovery",
  messages: "Messages",
  contracts: "Contracts",
  analytics: "Analytics",
  calendar: "Calendar",
  settings: "Settings",
  opportunities: "Opportunities",
  collaborations: "Collaborations",
  applications: "Applications",
  portfolio: "Portfolio",
  payments: "Payments",
  reviews: "Reviews",
};

function handleLogin(role) {
  appState.role = role;
  appState.screen = role;
  appState.page = "dashboard";
  render();
}

function handleLogout() {
  appState.screen = "landing";
  appState.role = null;
  appState.page = "dashboard";
  // reset auth widget too, so a fresh visit starts at the login form
  authState.mode = "login";
  authState.role = null;
  render();
}

function renderPageContent() {
  const isBrand = appState.role === "brand";
  const page = appState.page;

  if (isBrand) {
    if (page === "dashboard") return BrandDashboard();
    if (page === "campaigns") return BrandCampaigns();
    if (page === "discovery") return InfluencerDiscovery();
    if (page === "messages") return MessagesPage();
    if (page === "analytics") return BrandAnalytics();
  } else {
    if (page === "dashboard") return InfluencerDashboard();
    if (page === "opportunities") return Opportunities();
    if (page === "messages") return MessagesPage();
    if (page === "payments") return Payments();
    if (page === "analytics") return BrandAnalytics();
  }

  const title = PAGE_TITLES[page] || "Dashboard";
  return `
  <div style="padding:40px;text-align:center;">
    <div style="width:64px;height:64px;border-radius:20px;background:#EDE8F9;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
      ${Icon("dashboard", 28, COLORS.accent)}
    </div>
    <div style="font-weight:600;font-size:18px;margin-bottom:8px;">${title}</div>
    <div style="font-size:14px;color:${COLORS.textMuted};">This section is ready to be built. Select another page from the sidebar.</div>
  </div>`;
}

function render() {
  const root = document.getElementById("root");

  if (appState.screen === "landing") {
    root.innerHTML = LandingPage();
    return;
  }

  if (appState.screen === "auth") {
    root.innerHTML = AuthPage();
    return;
  }

  const title = PAGE_TITLES[appState.page] || "Dashboard";
  root.innerHTML = `
    <div style="display:flex;min-height:100vh;">
      ${Sidebar(appState.role, appState.page)}
      <div style="margin-left:220px;flex:1;display:flex;flex-direction:column;min-height:100vh;">
        ${Topbar(title)}
        <div style="flex:1;overflow-y:auto;background:${COLORS.bg};">
          ${renderPageContent()}
        </div>
      </div>
    </div>`;
}

// --- Central event delegation ---
// Every clickable element in the render functions above declares
// data-action (and optionally data-value) instead of an inline handler.
document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-action]");
  if (!el) return;

  const action = el.getAttribute("data-action");
  const value = el.getAttribute("data-value");

  switch (action) {
    case "goToAuth":
      appState.screen = "auth";
      render();
      break;

    case "setPage":
      appState.page = value;
      render();
      break;

    case "logout":
      handleLogout();
      break;

    case "login":
      handleLogin(value);
      break;

    case "setAuthMode":
      authState.mode = value;
      if (value === "login") authState.role = null;
      render();
      break;

    case "chooseRole":
      authState.role = value;
      render();
      break;

    default:
      // Unhandled action - no-op (buttons like "Edit", "Send", etc. are
      // presentational placeholders in this demo, same as the original).
      break;
  }
});

// Kick off the app
render();
