// ======================== AUTH PAGE ========================
// Local UI-only state for the auth screen (separate from the main app state)
const authState = { mode: "login", role: null };

function AuthPage() {
  const { mode, role } = authState;

  if (mode === "register" && !role) {
    const roleCards = [
      { id: "brand", label: "Brand", desc: "Launch campaigns and find creators", icon: "portfolio", color: COLORS.accent, bg: "#EDE8F9" },
      { id: "influencer", label: "Creator", desc: "Find brand deals and grow income", icon: "user", color: COLORS.success, bg: COLORS.successBg },
    ].map(r => `
      <div data-action="chooseRole" data-value="${r.id}" style="flex:1;background:${COLORS.bg};border:2px solid ${COLORS.border};border-radius:18px;padding:24px;cursor:pointer;text-align:center;transition:all .2s;">
        <div style="width:56px;height:56px;border-radius:16px;background:${r.bg};display:flex;align-items:center;justify-content:center;margin:0 auto 14px;">
          ${Icon(r.icon, 28, r.color)}
        </div>
        <div style="font-weight:700;font-size:16px;margin-bottom:6px;">${r.label}</div>
        <div style="font-size:12px;color:${COLORS.textMuted};line-height:1.5;">${r.desc}</div>
      </div>`).join("");

    return `
    <div style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:${COLORS.bg};">
      <div style="width:520px;background:${COLORS.white};border-radius:24px;padding:40px;box-shadow:0 8px 40px rgba(143,124,195,0.15);">
        <div style="text-align:center;margin-bottom:32px;">
          <div style="font-weight:700;font-size:22px;color:${COLORS.text};">Join Pressly</div>
          <div style="font-size:14px;color:${COLORS.textMuted};margin-top:6px;">Select your account type to continue</div>
        </div>
        <div style="display:flex;gap:16px;">${roleCards}</div>
        <div style="text-align:center;margin-top:20px;">
          <button data-action="setAuthMode" data-value="login" style="color:${COLORS.accent};font-size:13px;background:none;border:none;cursor:pointer;">Already have an account? Sign in</button>
        </div>
      </div>
    </div>`;
  }

  return `
  <div style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:${COLORS.bg};">
    <div style="width:420px;background:${COLORS.white};border-radius:24px;padding:40px;box-shadow:0 8px 40px rgba(143,124,195,0.15);">
      <div style="text-align:center;margin-bottom:28px;">
        <div style="width:44px;height:44px;border-radius:14px;background:linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender});display:flex;align-items:center;justify-content:center;margin:0 auto 14px;">
          ${Icon("globe", 22, "#fff")}
        </div>
        <div style="font-weight:700;font-size:22px;">${mode === "login" ? "Welcome back" : "Create account"}</div>
        <div style="font-size:13px;color:${COLORS.textMuted};margin-top:5px;">Sign ${mode === "login" ? "in" : "up"} to Pressly${role ? ` as a ${role}` : ""}</div>
      </div>

      <div style="display:flex;flex-direction:column;gap:14px;">
        ${mode === "register" ? `
          <div>
            <label style="font-size:12px;color:${COLORS.textMuted};font-weight:500;">Full name</label>
            <input placeholder="Your name" style="width:100%;margin-top:6px;padding:11px 14px;border-radius:12px;border:1.5px solid ${COLORS.border};font-size:14px;outline:none;background:${COLORS.bg};color:${COLORS.text};" />
          </div>` : ""}
        <div>
          <label style="font-size:12px;color:${COLORS.textMuted};font-weight:500;">Email</label>
          <input type="email" placeholder="you@example.com" style="width:100%;margin-top:6px;padding:11px 14px;border-radius:12px;border:1.5px solid ${COLORS.border};font-size:14px;outline:none;background:${COLORS.bg};color:${COLORS.text};" />
        </div>
        <div>
          <label style="font-size:12px;color:${COLORS.textMuted};font-weight:500;">Password</label>
          <input type="password" placeholder="••••••••" style="width:100%;margin-top:6px;padding:11px 14px;border-radius:12px;border:1.5px solid ${COLORS.border};font-size:14px;outline:none;background:${COLORS.bg};color:${COLORS.text};" />
        </div>
      </div>

      <div style="display:flex;gap:10px;margin-top:8px;">
        ${mode === "login" ? `
          ${Btn({ label: "Sign in as Brand", action: "login", value: "brand", extraStyle: "flex:1;justify-content:center;padding:11px;font-size:14px;" })}
          ${Btn({ label: "Sign in as Creator", variant: "secondary", action: "login", value: "influencer", extraStyle: "flex:1;justify-content:center;padding:11px;font-size:14px;" })}
        ` : `
          ${Btn({ label: "Create account", action: "login", value: role || "brand", extraStyle: "flex:1;justify-content:center;padding:11px;font-size:14px;" })}
        `}
      </div>

      <div style="text-align:center;margin-top:18px;font-size:13px;color:${COLORS.textMuted};">
        ${mode === "login"
          ? `<span>Don't have an account? <button data-action="setAuthMode" data-value="register" style="color:${COLORS.accent};background:none;border:none;cursor:pointer;font-weight:600;">Register</button></span>`
          : `<span>Already registered? <button data-action="setAuthMode" data-value="login" style="color:${COLORS.accent};background:none;border:none;cursor:pointer;font-weight:600;">Sign in</button></span>`}
      </div>
    </div>
  </div>`;
}
