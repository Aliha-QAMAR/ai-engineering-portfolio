// ======================== BRAND PAGES ========================

function BrandDashboard() {
  const stats = [
    { label: "Total campaigns", value: "24", icon: "campaign", color: COLORS.accent, bg: "#EDE8F9", sub: "+3 this month" },
    { label: "Active campaigns", value: "8", icon: "trending", color: "#E07070", bg: "#FCEAEA", sub: "2 ending soon" },
    { label: "Budget spent", value: "$42k", icon: "payment", color: COLORS.success, bg: COLORS.successBg, sub: "of $80k total" },
    { label: "Influencers", value: "137", icon: "users", color: COLORS.warning, bg: COLORS.warningBg, sub: "+12 new" },
  ];
  const campaigns = [
    { name: "Spring Collection 2025", status: "Active", budget: "$12,000", influencers: 8, progress: 65 },
    { name: "Summer Glow Campaign", status: "Review", budget: "$8,500", influencers: 4, progress: 40 },
    { name: "Accessories Launch", status: "Draft", budget: "$5,000", influencers: 0, progress: 10 },
  ];
  const statusColors = {
    Active: { color: COLORS.success, bg: COLORS.successBg },
    Review: { color: COLORS.warning, bg: COLORS.warningBg },
    Draft: { color: COLORS.textMuted, bg: COLORS.bg },
  };

  const chartBars = [40, 65, 50, 80, 72, 90, 68, 95, 78, 85, 92, 88]
    .map((v, i) => `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;"><div style="width:100%;border-radius:6px 6px 0 0;background:${i === 11 ? COLORS.accent : COLORS.lavender + "60"};height:${v}%;transition:all .5s;"></div></div>`)
    .join("");
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    .map(m => `<span style="font-size:10px;color:${COLORS.textLight};">${m}</span>`).join("");

  const quickActions = [
    { label: "Create campaign", icon: "plus", color: COLORS.accent },
    { label: "Find influencers", icon: "search", color: COLORS.success },
    { label: "View analytics", icon: "analytics", color: COLORS.warning },
    { label: "Send contract", icon: "contract", color: "#7B6FA0" },
  ].map(a => `
    <button style="width:100%;display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;border:1px solid ${COLORS.border};background:${COLORS.bg};cursor:pointer;margin-bottom:8px;color:${COLORS.text};font-size:13px;font-family:Poppins;">
      <div style="width:30px;height:30px;border-radius:9px;background:${a.color}20;display:flex;align-items:center;justify-content:center;">
        ${Icon(a.icon, 15, a.color)}
      </div>
      ${a.label}
      <span style="margin-left:auto;">${Icon("arrow", 14, COLORS.textLight)}</span>
    </button>`).join("");

  const tableRows = campaigns.map(c => `
    <tr style="border-bottom:1px solid ${COLORS.bg};">
      <td style="padding:12px 12px;font-size:13px;font-weight:500;color:${COLORS.text};">${c.name}</td>
      <td style="padding:12px 12px;">${Badge({ label: c.status, color: statusColors[c.status].color, bg: statusColors[c.status].bg })}</td>
      <td style="padding:12px 12px;font-size:13px;color:${COLORS.textMuted};">${c.budget}</td>
      <td style="padding:12px 12px;font-size:13px;color:${COLORS.textMuted};">${c.influencers}</td>
      <td style="padding:12px 12px;">
        <div style="display:flex;align-items:center;gap:8px;">
          <div style="flex:1;height:6px;border-radius:3px;background:${COLORS.border};">
            <div style="width:${c.progress}%;height:100%;border-radius:3px;background:linear-gradient(90deg, ${COLORS.accent}, ${COLORS.lavender});"></div>
          </div>
          <span style="font-size:11px;color:${COLORS.textMuted};min-width:30px;">${c.progress}%</span>
        </div>
      </td>
    </tr>`).join("");

  return `
  <div style="padding:28px;">
    <div style="margin-bottom:24px;">
      <p style="font-size:14px;color:${COLORS.textMuted};">Good morning, Zara Fashion 👋 Here's what's happening today.</p>
    </div>

    <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:16px;margin-bottom:28px;">
      ${stats.map(s => StatCard(s)).join("")}
    </div>

    <div style="display:grid;grid-template-columns:1.7fr 1fr;gap:20px;margin-bottom:20px;">
      <div style="background:${COLORS.white};border-radius:18px;padding:22px;box-shadow:${COLORS.cardShadow};">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
          <div style="font-weight:600;font-size:15px;">Campaign performance</div>
          ${Badge({ label: "Last 30 days" })}
        </div>
        <div style="display:flex;gap:8px;align-items:flex-end;height:120px;">${chartBars}</div>
        <div style="display:flex;justify-content:space-between;margin-top:8px;">${months}</div>
      </div>

      <div style="background:${COLORS.white};border-radius:18px;padding:22px;box-shadow:${COLORS.cardShadow};">
        <div style="font-weight:600;font-size:15px;margin-bottom:16px;">Quick actions</div>
        ${quickActions}
      </div>
    </div>

    <div style="background:${COLORS.white};border-radius:18px;padding:22px;box-shadow:${COLORS.cardShadow};">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
        <div style="font-weight:600;font-size:15px;">Recent campaigns</div>
        ${Btn({ label: "View all", variant: "ghost" })}
      </div>
      <table>
        <thead>
          <tr style="border-bottom:1px solid ${COLORS.border};">
            ${["Campaign", "Status", "Budget", "Influencers", "Progress"].map(h => `<th style="text-align:left;padding:8px 12px;font-size:12px;color:${COLORS.textMuted};font-weight:500;">${h}</th>`).join("")}
          </tr>
        </thead>
        <tbody>${tableRows}</tbody>
      </table>
    </div>
  </div>`;
}

function BrandCampaigns() {
  const campaigns = [
    { name: "Spring Collection 2025", status: "Active", budget: "$12,000", used: "$7,800", influencers: 8, deadline: "Mar 30", progress: 65 },
    { name: "Summer Glow Campaign", status: "In Review", budget: "$8,500", used: "$3,400", influencers: 4, deadline: "Apr 15", progress: 40 },
    { name: "Accessories Launch", status: "Draft", budget: "$5,000", used: "$0", influencers: 0, deadline: "May 1", progress: 10 },
    { name: "Holiday Special Edition", status: "Completed", budget: "$20,000", used: "$19,200", influencers: 15, deadline: "Dec 31", progress: 100 },
  ];
  const statusColors = {
    Active: { c: COLORS.success, bg: COLORS.successBg },
    "In Review": { c: COLORS.warning, bg: COLORS.warningBg },
    Draft: { c: COLORS.textMuted, bg: COLORS.bg },
    Completed: { c: COLORS.accent, bg: "#EDE8F9" },
  };

  const cards = campaigns.map(c => {
    const sc = statusColors[c.status];
    const metrics = [
      { label: "Total budget", value: c.budget },
      { label: "Spent", value: c.used },
      { label: "Influencers", value: c.influencers },
      { label: "Deadline", value: c.deadline },
    ].map(m => `
      <div style="background:${COLORS.bg};border-radius:12px;padding:10px 14px;">
        <div style="font-size:12px;color:${COLORS.textMuted};">${m.label}</div>
        <div style="font-size:15px;font-weight:600;color:${COLORS.text};margin-top:2px;">${m.value}</div>
      </div>`).join("");

    return `
    <div style="background:${COLORS.white};border-radius:18px;padding:20px 24px;box-shadow:${COLORS.cardShadow};">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;">
        <div>
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="font-weight:600;font-size:16px;color:${COLORS.text};">${c.name}</div>
            ${Badge({ label: c.status, color: sc.c, bg: sc.bg })}
          </div>
          <div style="font-size:12px;color:${COLORS.textMuted};margin-top:4px;">Deadline: ${c.deadline} · ${c.influencers} influencers</div>
        </div>
        <div style="display:flex;gap:8px;">
          ${Btn({ label: "Edit", variant: "secondary", extraStyle: "padding:7px 14px;font-size:12px;" })}
          ${Btn({ label: "View details", extraStyle: "padding:7px 14px;font-size:12px;" })}
        </div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:12px;margin-bottom:16px;">${metrics}</div>

      <div style="display:flex;align-items:center;gap:10px;">
        <div style="flex:1;height:7px;border-radius:4px;background:${COLORS.border};">
          <div style="width:${c.progress}%;height:100%;border-radius:4px;background:linear-gradient(90deg, ${COLORS.accent}, ${COLORS.lavender});transition:width .5s;"></div>
        </div>
        <span style="font-size:12px;color:${COLORS.textMuted};min-width:35px;">${c.progress}%</span>
      </div>
    </div>`;
  }).join("");

  return `
  <div style="padding:28px;">
    <div style="display:flex;justify-content:space-between;margin-bottom:24px;">
      <p style="font-size:14px;color:${COLORS.textMuted};">Manage and track all your PR campaigns.</p>
      ${Btn({ label: `${Icon("plus", 15, "#fff")} New campaign` })}
    </div>
    <div style="display:grid;gap:14px;">${cards}</div>
  </div>`;
}

function InfluencerDiscovery() {
  const influencers = [
    { name: "Sophia Zhang", category: "Fashion & Style", followers: "245K", engagement: "4.8%", price: "$800/post", platforms: ["IG", "TT"], verified: true, rating: 4.9 },
    { name: "Aiden Malik", category: "Tech & Gadgets", followers: "182K", engagement: "6.2%", price: "$650/post", platforms: ["YT", "IG"], verified: true, rating: 4.7 },
    { name: "Priya Sharma", category: "Beauty & Skincare", followers: "320K", engagement: "5.5%", price: "$1,100/post", platforms: ["IG", "TT", "YT"], verified: true, rating: 4.9 },
    { name: "Lucas Ferreira", category: "Fitness & Health", followers: "98K", engagement: "7.8%", price: "$400/post", platforms: ["IG", "TT"], verified: false, rating: 4.5 },
    { name: "Emma Christensen", category: "Travel & Lifestyle", followers: "415K", engagement: "3.9%", price: "$1,500/post", platforms: ["IG", "YT"], verified: true, rating: 4.8 },
    { name: "Yusuf Adeyemi", category: "Food & Culture", followers: "67K", engagement: "9.1%", price: "$280/post", platforms: ["TT", "IG"], verified: false, rating: 4.6 },
  ];
  const platformColors = { IG: { bg: "#FCE4EC", color: "#C2185B" }, TT: { bg: "#E8F5E9", color: "#2E7D32" }, YT: { bg: "#FFEBEE", color: "#C62828" } };

  const filterPills = ["All categories", "Fashion", "Beauty", "Tech", "Travel", "Food", "Fitness"]
    .map((f, i) => `<button style="padding:6px 14px;border-radius:20px;border:1px solid ${i === 0 ? COLORS.accent : COLORS.border};background:${i === 0 ? COLORS.accent + "15" : COLORS.white};color:${i === 0 ? COLORS.accent : COLORS.textMuted};font-size:12px;cursor:pointer;font-family:Poppins;font-weight:${i === 0 ? 600 : 400};">${f}</button>`)
    .join("");

  const cards = influencers.map(inf => {
    const metrics = [
      { label: "Followers", value: inf.followers },
      { label: "Engagement", value: inf.engagement },
      { label: "Rating", value: `⭐ ${inf.rating}` },
    ].map(m => `
      <div style="background:${COLORS.bg};border-radius:10px;padding:8px 10px;text-align:center;">
        <div style="font-size:13px;font-weight:700;color:${COLORS.text};">${m.value}</div>
        <div style="font-size:10px;color:${COLORS.textMuted};">${m.label}</div>
      </div>`).join("");

    const platformBadges = inf.platforms.map(p => Badge({ label: p, color: platformColors[p]?.color, bg: platformColors[p]?.bg })).join("");

    return `
    <div class="hoverable" style="background:${COLORS.white};border-radius:18px;padding:20px;box-shadow:${COLORS.cardShadow};cursor:pointer;">
      <div style="display:flex;justify-content:space-between;margin-bottom:14px;">
        <div style="display:flex;gap:12px;align-items:center;">
          ${Avatar({ name: inf.name, size: 44 })}
          <div>
            <div style="display:flex;align-items:center;gap:5px;">
              <div style="font-weight:600;font-size:14px;color:${COLORS.text};">${inf.name}</div>
              ${inf.verified ? `<span style="color:${COLORS.accent};font-size:13px;">✓</span>` : ""}
            </div>
            <div style="font-size:11px;color:${COLORS.textMuted};">${inf.category}</div>
          </div>
        </div>
        <button style="background:${COLORS.bg};border:none;border-radius:10px;width:30px;height:30px;display:flex;align-items:center;justify-content:center;cursor:pointer;">
          ${Icon("bookmark", 15, COLORS.textLight)}
        </button>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:14px;">${metrics}</div>
      <div style="display:flex;gap:6px;margin-bottom:14px;">${platformBadges}</div>

      <div style="display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:13px;font-weight:600;color:${COLORS.accent};">${inf.price}</span>
        <div style="display:flex;gap:8px;">
          ${Btn({ label: `${Icon("eye", 13, "currentColor")}View`, variant: "secondary", extraStyle: "padding:6px 12px;font-size:12px;" })}
          ${Btn({ label: "Invite", extraStyle: "padding:6px 12px;font-size:12px;" })}
        </div>
      </div>
    </div>`;
  }).join("");

  return `
  <div style="padding:28px;">
    <div style="display:flex;gap:12px;margin-bottom:24px;align-items:center;">
      <div style="flex:1;display:flex;gap:8px;background:${COLORS.white};border-radius:14px;padding:10px 16px;border:1px solid ${COLORS.border};">
        ${Icon("search", 16, COLORS.textLight)}
        <input placeholder="Search influencers by name, niche, or platform..." style="flex:1;border:none;outline:none;font-size:13px;color:${COLORS.text};background:transparent;" />
      </div>
      ${Btn({ label: `${Icon("filter", 15, "currentColor")}Filters`, variant: "secondary" })}
      ${Btn({ label: `${Icon("users", 15, "#fff")}Find matches` })}
    </div>

    <div style="display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;">${filterPills}</div>

    <div style="display:grid;grid-template-columns:repeat(3, 1fr);gap:16px;">${cards}</div>
  </div>`;
}

function BrandAnalytics() {
  const stats = [
    { label: "Total reach", value: "2.4M", icon: "globe", color: COLORS.accent, bg: "#EDE8F9" },
    { label: "Engagements", value: "186K", icon: "trending", color: COLORS.success, bg: COLORS.successBg },
    { label: "Conversions", value: "4,820", icon: "check", color: COLORS.warning, bg: COLORS.warningBg },
    { label: "ROI", value: "340%", icon: "analytics", color: "#C2185B", bg: "#FCE4EC" },
  ];

  const chartCols = [55, 70, 45, 90, 80, 65, 95, 75, 85, 100, 88, 92].map(v => `
    <div style="flex:1;display:flex;flex-direction:column;gap:3px;align-items:center;height:100%;">
      <div style="width:100%;border-radius:5px 5px 0 0;background:${COLORS.lavender}50;height:${v * 0.7}%;"></div>
      <div style="width:100%;border-radius:5px 5px 0 0;background:${COLORS.accent}90;height:${v * 0.3}%;"></div>
    </div>`).join("");

  const platformRows = [
    { p: "Instagram", pct: 52, color: "#C2185B" },
    { p: "TikTok", pct: 28, color: COLORS.success },
    { p: "YouTube", pct: 15, color: COLORS.error },
    { p: "Facebook", pct: 5, color: "#1565C0" },
  ].map(item => `
    <div style="margin-bottom:14px;">
      <div style="display:flex;justify-content:space-between;margin-bottom:5px;">
        <span style="font-size:13px;color:${COLORS.text};">${item.p}</span>
        <span style="font-size:13px;font-weight:600;color:${COLORS.text};">${item.pct}%</span>
      </div>
      <div style="height:7px;border-radius:4px;background:${COLORS.border};">
        <div style="width:${item.pct}%;height:100%;border-radius:4px;background:${item.color};"></div>
      </div>
    </div>`).join("");

  return `
  <div style="padding:28px;">
    <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:16px;margin-bottom:24px;">
      ${stats.map(s => StatCard(s)).join("")}
    </div>

    <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:20px;">
      <div style="background:${COLORS.white};border-radius:18px;padding:22px;box-shadow:${COLORS.cardShadow};">
        <div style="font-weight:600;font-size:15px;margin-bottom:20px;">Reach & engagement over time</div>
        <div style="display:flex;gap:6px;align-items:flex-end;height:140px;">${chartCols}</div>
        <div style="display:flex;gap:16px;margin-top:12px;">
          <span style="font-size:12px;color:${COLORS.textMuted};display:flex;align-items:center;gap:5px;"><span style="width:10px;height:10px;border-radius:2px;background:${COLORS.lavender}80;display:inline-block;"></span>Reach</span>
          <span style="font-size:12px;color:${COLORS.textMuted};display:flex;align-items:center;gap:5px;"><span style="width:10px;height:10px;border-radius:2px;background:${COLORS.accent}90;display:inline-block;"></span>Engagement</span>
        </div>
      </div>

      <div style="background:${COLORS.white};border-radius:18px;padding:22px;box-shadow:${COLORS.cardShadow};">
        <div style="font-weight:600;font-size:15px;margin-bottom:18px;">Platform breakdown</div>
        ${platformRows}
      </div>
    </div>
  </div>`;
}
