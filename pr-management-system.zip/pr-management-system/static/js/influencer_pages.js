// ======================== INFLUENCER PAGES ========================

function InfluencerDashboard() {
  const stats = [
    { label: "Active campaigns", value: "3", icon: "campaign", color: COLORS.accent, bg: "#EDE8F9", sub: "1 new offer" },
    { label: "Total earnings", value: "$8,400", icon: "payment", color: COLORS.success, bg: COLORS.successBg, sub: "+$1,200 this month" },
    { label: "Applications", value: "12", icon: "bookmark", color: COLORS.warning, bg: COLORS.warningBg, sub: "3 pending" },
    { label: "Profile views", value: "2.1K", icon: "eye", color: "#C2185B", bg: "#FCE4EC", sub: "This week" },
  ];

  const activeCampaigns = [
    { brand: "Zara Fashion", campaign: "Spring Collection 2025", deadline: "Mar 30", status: "In progress", pay: "$800" },
    { brand: "L'Oréal Paris", campaign: "Glow Up Series", deadline: "Apr 5", status: "Deliverable due", pay: "$1,200" },
    { brand: "Nike Women", campaign: "She Moves Campaign", deadline: "Apr 20", status: "Brief review", pay: "$650" },
  ].map(c => `
    <div style="display:flex;gap:12px;padding:12px 0;border-bottom:1px solid ${COLORS.bg};align-items:center;">
      ${Avatar({ name: c.brand, size: 38, color: "#8E7CC3", bg: "#EDE8F9" })}
      <div style="flex:1;">
        <div style="font-size:13px;font-weight:600;">${c.campaign}</div>
        <div style="font-size:11px;color:${COLORS.textMuted};">${c.brand} · Due ${c.deadline}</div>
      </div>
      <div style="text-align:right;">
        <div style="font-size:13px;font-weight:600;color:${COLORS.accent};">${c.pay}</div>
        ${Badge({ label: c.status, color: COLORS.warning, bg: COLORS.warningBg })}
      </div>
    </div>`).join("");

  return `
  <div style="padding:28px;">
    <div style="background:linear-gradient(135deg, ${COLORS.accent}22, ${COLORS.lavender}22);border-radius:20px;padding:20px 24px;margin-bottom:24px;border:1px solid ${COLORS.border};">
      <div style="display:flex;align-items:center;gap:16px;">
        ${Avatar({ name: "Ayla Rahman", size: 56 })}
        <div style="flex:1;">
          <div style="font-weight:700;font-size:18px;">Ayla Rahman</div>
          <div style="font-size:13px;color:${COLORS.textMuted};">Fashion & Lifestyle · 128K followers</div>
          <div style="display:flex;gap:8px;margin-top:8px;">
            ${Badge({ label: "Verified", color: COLORS.success, bg: COLORS.successBg })}
            ${Badge({ label: "Top Creator", color: COLORS.accent, bg: "#EDE8F9" })}
          </div>
        </div>
        <div style="text-align:right;">
          <div style="font-size:12px;color:${COLORS.textMuted};">Profile completion</div>
          <div style="font-size:22px;font-weight:700;color:${COLORS.accent};">82%</div>
          <div style="width:120px;height:6px;border-radius:3px;background:${COLORS.border};margin-top:4px;">
            <div style="width:82%;height:100%;border-radius:3px;background:linear-gradient(90deg, ${COLORS.accent}, ${COLORS.lavender});"></div>
          </div>
        </div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:16px;margin-bottom:24px;">
      ${stats.map(s => StatCard(s)).join("")}
    </div>

    <div style="display:grid;grid-template-columns:1.4fr 1fr;gap:20px;">
      <div style="background:${COLORS.white};border-radius:18px;padding:22px;box-shadow:${COLORS.cardShadow};">
        <div style="font-weight:600;font-size:15px;margin-bottom:16px;">Active campaigns</div>
        ${activeCampaigns}
      </div>

      <div style="background:${COLORS.white};border-radius:18px;padding:22px;box-shadow:${COLORS.cardShadow};">
        <div style="font-weight:600;font-size:15px;margin-bottom:16px;">Followers growth</div>
        ${MiniChart([62, 70, 68, 80, 76, 90, 88, 95, 100, 98, 105, 128], COLORS.accent)}
        <div style="display:flex;justify-content:space-between;margin-top:8px;">
          <span style="font-size:10px;color:${COLORS.textLight};">Jan</span>
          <span style="font-size:10px;color:${COLORS.textLight};">Dec</span>
        </div>
        <div style="margin-top:16px;padding:12px;background:${COLORS.bg};border-radius:12px;">
          <div style="font-size:11px;color:${COLORS.textMuted};">Current followers</div>
          <div style="font-size:22px;font-weight:700;color:${COLORS.text};">128,400</div>
          <div style="font-size:12px;color:${COLORS.success};">↑ 6.8% this month</div>
        </div>
      </div>
    </div>
  </div>`;
}

function Opportunities() {
  const opportunities = [
    { brand: "Chanel Beauty", campaign: "Elegance Redefined", budget: "$1,500/post", category: "Beauty", deadline: "Apr 10", followers: "100K+", fit: 98 },
    { brand: "Adidas Women", campaign: "She Runs the World", budget: "$900/post", category: "Fitness", deadline: "Apr 20", followers: "50K+", fit: 85 },
    { brand: "Glossier", campaign: "Skin First Campaign", budget: "$700/post", category: "Skincare", deadline: "May 1", followers: "80K+", fit: 91 },
    { brand: "H&M Studio", campaign: "Sustainable Fashion 2025", budget: "$1,100/post", category: "Fashion", deadline: "Apr 30", followers: "120K+", fit: 96 },
  ];

  const cards = opportunities.map(o => `
    <div style="background:${COLORS.white};border-radius:18px;padding:20px 24px;box-shadow:${COLORS.cardShadow};">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;">
        <div style="display:flex;gap:14px;align-items:center;">
          ${Avatar({ name: o.brand, size: 48 })}
          <div>
            <div style="font-weight:700;font-size:15px;color:${COLORS.text};">${o.campaign}</div>
            <div style="font-size:13px;color:${COLORS.textMuted};">${o.brand}</div>
            <div style="display:flex;gap:6px;margin-top:6px;">
              ${Badge({ label: o.category })}
              ${Badge({ label: `${o.followers} required`, color: COLORS.textMuted, bg: COLORS.bg })}
            </div>
          </div>
        </div>
        <div style="text-align:right;">
          <div style="font-size:11px;color:${COLORS.textMuted};">Match score</div>
          <div style="font-size:22px;font-weight:700;color:${o.fit >= 90 ? COLORS.success : COLORS.warning};">${o.fit}%</div>
        </div>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-top:16px;padding-top:14px;border-top:1px solid ${COLORS.bg};">
        <div style="display:flex;gap:20px;">
          <div><span style="font-size:11px;color:${COLORS.textMuted};">Pay</span> <span style="font-size:14px;font-weight:700;color:${COLORS.accent};">${o.budget}</span></div>
          <div><span style="font-size:11px;color:${COLORS.textMuted};">Deadline</span> <span style="font-size:13px;font-weight:500;"> ${o.deadline}</span></div>
        </div>
        <div style="display:flex;gap:8px;">
          ${Btn({ label: `${Icon("bookmark", 13, "currentColor")}Save`, variant: "secondary", extraStyle: "padding:7px 14px;font-size:12px;" })}
          ${Btn({ label: "Apply now", extraStyle: "padding:7px 16px;font-size:12px;" })}
        </div>
      </div>
    </div>`).join("");

  return `
  <div style="padding:28px;">
    <div style="margin-bottom:20px;">
      <p style="font-size:14px;color:${COLORS.textMuted};">Campaigns matched to your profile and niche.</p>
    </div>
    <div style="display:grid;gap:16px;">${cards}</div>
  </div>`;
}

function Payments() {
  const transactions = [
    { brand: "Zara Fashion", campaign: "Spring Campaign", amount: "+$800", date: "Mar 10", status: "Paid" },
    { brand: "L'Oréal Paris", campaign: "Glow Up Series", amount: "+$1,200", date: "Mar 5", status: "Pending" },
    { brand: "Nike Women", campaign: "She Moves", amount: "+$650", date: "Feb 22", status: "Paid" },
    { brand: "H&M Studio", campaign: "Sustainable Fashion", amount: "+$1,100", date: "Feb 10", status: "Paid" },
  ].map(t => `
    <div style="display:flex;align-items:center;gap:14px;padding:14px 0;border-bottom:1px solid ${COLORS.bg};">
      ${Avatar({ name: t.brand, size: 38 })}
      <div style="flex:1;">
        <div style="font-size:13px;font-weight:600;">${t.campaign}</div>
        <div style="font-size:11px;color:${COLORS.textMuted};">${t.brand} · ${t.date}</div>
      </div>
      <div style="text-align:right;">
        <div style="font-size:15px;font-weight:700;color:${COLORS.success};">${t.amount}</div>
        ${Badge({ label: t.status, color: t.status === "Paid" ? COLORS.success : COLORS.warning, bg: t.status === "Paid" ? COLORS.successBg : COLORS.warningBg })}
      </div>
    </div>`).join("");

  return `
  <div style="padding:28px;">
    <div style="display:grid;grid-template-columns:repeat(3, 1fr);gap:16px;margin-bottom:24px;">
      ${StatCard({ label: "Total earned", value: "$8,400", icon: "payment", color: COLORS.success, bg: COLORS.successBg, sub: "All time" })}
      ${StatCard({ label: "Pending", value: "$1,950", icon: "calendar", color: COLORS.warning, bg: COLORS.warningBg, sub: "2 invoices" })}
      ${StatCard({ label: "Withdrawn", value: "$6,450", icon: "analytics", color: COLORS.accent, bg: "#EDE8F9", sub: "To bank account" })}
    </div>
    <div style="background:${COLORS.white};border-radius:18px;padding:22px;box-shadow:${COLORS.cardShadow};">
      <div style="display:flex;justify-content:space-between;margin-bottom:18px;">
        <div style="font-weight:600;font-size:15px;">Transaction history</div>
        ${Btn({ label: "Export PDF", variant: "secondary", extraStyle: "font-size:12px;padding:7px 14px;" })}
      </div>
      ${transactions}
    </div>
  </div>`;
}

// ======================== MESSAGES (shared by both roles) ========================
function MessagesPage() {
  const convos = [
    { name: "Priya Sharma", last: "Looking forward to our collaboration!", time: "2m", unread: 2, active: true },
    { name: "Emma Christensen", last: "Can you send the brief?", time: "15m", unread: 0, active: false },
    { name: "Sophia Zhang", last: "Contract signed ✓", time: "1h", unread: 0, active: false },
    { name: "Aiden Malik", last: "Here are the deliverables", time: "3h", unread: 1, active: false },
    { name: "Lucas Ferreira", last: "Payment received, thank you!", time: "1d", unread: 0, active: false },
  ];
  const msgs = [
    { from: "them", text: "Hi! I reviewed the campaign brief and I'm very excited to work on this.", time: "10:02" },
    { from: "me", text: "Great! We'd love to have you. The budget we discussed works?", time: "10:05" },
    { from: "them", text: "Yes, that works perfectly. When do you need the first deliverable?", time: "10:07" },
    { from: "me", text: "By March 15th if possible. We're targeting the spring collection launch.", time: "10:09" },
    { from: "them", text: "Looking forward to our collaboration!", time: "10:12" },
  ];

  const convoItems = convos.map(c => `
    <div style="display:flex;gap:10px;padding:12px 8px;border-radius:12px;background:${c.active ? COLORS.accent + "12" : "transparent"};cursor:pointer;margin-bottom:2px;">
      ${Avatar({ name: c.name, size: 40 })}
      <div style="flex:1;min-width:0;">
        <div style="display:flex;justify-content:space-between;">
          <div style="font-weight:${c.unread ? 600 : 500};font-size:13px;color:${COLORS.text};">${c.name}</div>
          <div style="font-size:10px;color:${COLORS.textLight};">${c.time}</div>
        </div>
        <div style="font-size:12px;color:${COLORS.textMuted};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${c.last}</div>
      </div>
      ${c.unread > 0 ? `<div style="width:18px;height:18px;border-radius:50%;background:${COLORS.accent};color:#fff;font-size:10px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;">${c.unread}</div>` : ""}
    </div>`).join("");

  const bubbles = msgs.map(m => `
    <div style="display:flex;justify-content:${m.from === "me" ? "flex-end" : "flex-start"};gap:8px;align-items:flex-end;">
      ${m.from === "them" ? Avatar({ name: "Priya Sharma", size: 28 }) : ""}
      <div style="max-width:65%;background:${m.from === "me" ? `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender})` : COLORS.white};color:${m.from === "me" ? "#fff" : COLORS.text};border-radius:${m.from === "me" ? "18px 18px 4px 18px" : "18px 18px 18px 4px"};padding:10px 14px;font-size:13px;box-shadow:${COLORS.cardShadow};">
        ${m.text}
        <div style="font-size:10px;opacity:0.7;margin-top:4px;text-align:right;">${m.time}</div>
      </div>
    </div>`).join("");

  return `
  <div style="display:flex;height:calc(100vh - 65px);overflow:hidden;">
    <div style="width:280px;border-right:1px solid ${COLORS.border};background:${COLORS.white};overflow-y:auto;">
      <div style="padding:16px;">
        <div style="display:flex;gap:8px;background:${COLORS.bg};border-radius:12px;padding:8px 12px;margin-bottom:12px;border:1px solid ${COLORS.border};">
          ${Icon("search", 15, COLORS.textLight)}
          <input placeholder="Search messages..." style="flex:1;border:none;background:transparent;outline:none;font-size:12px;" />
        </div>
        ${convoItems}
      </div>
    </div>

    <div style="flex:1;display:flex;flex-direction:column;background:${COLORS.bg};">
      <div style="padding:14px 20px;background:${COLORS.white};border-bottom:1px solid ${COLORS.border};display:flex;align-items:center;gap:12px;">
        ${Avatar({ name: "Priya Sharma", size: 36 })}
        <div>
          <div style="font-weight:600;font-size:14px;">Priya Sharma</div>
          <div style="font-size:12px;color:${COLORS.success};">● Online</div>
        </div>
      </div>

      <div style="flex:1;padding:20px;overflow-y:auto;display:flex;flex-direction:column;gap:12px;">
        ${bubbles}
      </div>

      <div style="padding:14px 20px;background:${COLORS.white};border-top:1px solid ${COLORS.border};">
        <div style="display:flex;gap:10px;align-items:center;background:${COLORS.bg};border-radius:14px;padding:10px 16px;border:1px solid ${COLORS.border};">
          <input placeholder="Type a message..." style="flex:1;border:none;background:transparent;outline:none;font-size:13px;" />
          ${Btn({ label: "Send", extraStyle: "padding:7px 16px;font-size:12px;" })}
        </div>
      </div>
    </div>
  </div>`;
}
