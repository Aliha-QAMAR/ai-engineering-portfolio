// ======================== LANDING PAGE ========================
function LandingPage() {
  const navLinks = ["Features", "About", "Pricing", "Contact"]
    .map(l => `<a href="#" style="font-size:14px;color:${COLORS.textMuted};font-weight:500;">${l}</a>`)
    .join("");

  const features = [
    { icon: "campaign", title: "Campaign management", desc: "Create, launch, and track PR campaigns with full budget control and timeline management.", color: COLORS.accent, bg: "#EDE8F9" },
    { icon: "users", title: "Influencer discovery", desc: "Find the perfect creators by niche, followers, engagement rate, location, and more.", color: COLORS.success, bg: COLORS.successBg },
    { icon: "analytics", title: "Performance analytics", desc: "Deep insights into reach, engagement, conversions, and ROI across all campaigns.", color: COLORS.warning, bg: COLORS.warningBg },
    { icon: "message", title: "Secure messaging", desc: "Professional in-platform communication with file sharing and media attachments.", color: "#C2185B", bg: "#FCE4EC" },
    { icon: "contract", title: "Smart contracts", desc: "Generate, sign, and manage contracts digitally — fully legally compliant.", color: "#7B6FA0", bg: "#F0EBF9" },
    { icon: "payment", title: "Payments & invoicing", desc: "Seamless payment flows for influencers with invoice tracking and withdrawal requests.", color: "#1565C0", bg: "#E3F2FD" },
  ];

  const featureCards = features.map(f => `
    <div style="background:${COLORS.bg};border-radius:18px;padding:22px;border:1px solid ${COLORS.border};">
      <div style="width:44px;height:44px;border-radius:14px;background:${f.bg};display:flex;align-items:center;justify-content:center;margin-bottom:14px;">
        ${Icon(f.icon, 22, f.color)}
      </div>
      <div style="font-weight:600;font-size:15px;margin-bottom:8px;">${f.title}</div>
      <div style="font-size:13px;color:${COLORS.textMuted};line-height:1.6;">${f.desc}</div>
    </div>`).join("");

  return `
  <div style="min-height:100vh;background:${COLORS.bg};font-family:'Poppins', sans-serif;">
    <nav style="display:flex;align-items:center;justify-content:space-between;padding:16px 60px;background:${COLORS.white};border-bottom:1px solid ${COLORS.border};position:sticky;top:0;z-index:100;">
      <div style="display:flex;align-items:center;gap:9px;">
        <div style="width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender});display:flex;align-items:center;justify-content:center;">
          ${Icon("globe", 17, "#fff")}
        </div>
        <span style="font-weight:700;font-size:18px;color:${COLORS.text};">Pressly</span>
      </div>
      <div style="display:flex;gap:28px;">${navLinks}</div>
      <div style="display:flex;gap:10px;">
        ${Btn({ label: "Sign in", variant: "secondary", action: "goToAuth" })}
        ${Btn({ label: "Get started free", action: "goToAuth" })}
      </div>
    </nav>

    <div style="text-align:center;padding:80px 60px 60px;max-width:800px;margin:0 auto;">
      <div style="display:inline-flex;align-items:center;gap:6px;background:#EDE8F9;border-radius:20px;padding:5px 14px;margin-bottom:24px;font-size:12px;color:${COLORS.accent};font-weight:600;">
        ✨ The smart PR platform for influencer marketing
      </div>
      <h1 style="font-size:52px;font-weight:800;color:${COLORS.text};line-height:1.15;margin-bottom:20px;">
        Connect Brands with<br />
        <span style="background:linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender});-webkit-background-clip:text;-webkit-text-fill-color:transparent;">the Right Influencers</span>
      </h1>
      <p style="font-size:18px;color:${COLORS.textMuted};line-height:1.7;margin-bottom:36px;">
        Pressly streamlines PR campaigns, influencer discovery, contracts, and analytics in one elegant platform built for modern brands and creators.
      </p>
      <div style="display:flex;gap:12px;justify-content:center;">
        ${Btn({ label: `${Icon("arrow", 17, "#fff")} Start for free`, extraStyle: "font-size:15px;padding:13px 28px;", action: "goToAuth" })}
        ${Btn({ label: "Watch demo", variant: "secondary", extraStyle: "font-size:15px;padding:13px 28px;" })}
      </div>
    </div>

    <div style="padding:60px;background:${COLORS.white};">
      <div style="text-align:center;margin-bottom:40px;">
        <h2 style="font-size:32px;font-weight:700;color:${COLORS.text};margin-bottom:10px;">Everything you need</h2>
        <p style="font-size:16px;color:${COLORS.textMuted};">Powerful tools for brands and creators alike.</p>
      </div>
      <div style="display:grid;grid-template-columns:repeat(3, 1fr);gap:20px;max-width:1000px;margin:0 auto;">
        ${featureCards}
      </div>
    </div>

    <div style="padding:60px;text-align:center;">
      <h2 style="font-size:28px;font-weight:700;margin-bottom:10px;">Who are you?</h2>
      <p style="font-size:15px;color:${COLORS.textMuted};margin-bottom:36px;">Choose your role to explore the tailored experience.</p>
      <div style="display:flex;gap:20px;justify-content:center;">
        <div data-action="goToAuth" style="width:260px;background:${COLORS.white};border-radius:20px;padding:28px;border:2px solid ${COLORS.accent};cursor:pointer;text-align:left;box-shadow:${COLORS.cardShadow};">
          <div style="width:50px;height:50px;border-radius:15px;background:#EDE8F9;display:flex;align-items:center;justify-content:center;margin-bottom:16px;">
            ${Icon("portfolio", 26, COLORS.accent)}
          </div>
          <div style="font-weight:700;font-size:16px;margin-bottom:6px;">I'm a Brand</div>
          <div style="font-size:13px;color:${COLORS.textMuted};line-height:1.6;">Launch campaigns, discover creators, and manage your PR strategy.</div>
          <div style="margin-top:14px;display:flex;align-items:center;gap:5px;color:${COLORS.accent};font-size:13px;font-weight:600;">Get started ${Icon("arrow", 14, COLORS.accent)}</div>
        </div>
        <div data-action="goToAuth" style="width:260px;background:${COLORS.white};border-radius:20px;padding:28px;border:1px solid ${COLORS.border};cursor:pointer;text-align:left;">
          <div style="width:50px;height:50px;border-radius:15px;background:${COLORS.successBg};display:flex;align-items:center;justify-content:center;margin-bottom:16px;">
            ${Icon("user", 26, COLORS.success)}
          </div>
          <div style="font-weight:700;font-size:16px;margin-bottom:6px;">I'm a Creator</div>
          <div style="font-size:13px;color:${COLORS.textMuted};line-height:1.6;">Find brand partnerships, manage applications, and grow your income.</div>
          <div style="margin-top:14px;display:flex;align-items:center;gap:5px;color:${COLORS.success};font-size:13px;font-weight:600;">Get started ${Icon("arrow", 14, COLORS.success)}</div>
        </div>
      </div>
    </div>
  </div>`;
}
