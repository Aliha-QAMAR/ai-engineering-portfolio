// --- SIDEBAR ---
function Sidebar(role, page) {
  const brandNav = [
    { id: "dashboard", label: "Dashboard", icon: "dashboard" },
    { id: "campaigns", label: "Campaigns", icon: "campaign" },
    { id: "discovery", label: "Influencer Discovery", icon: "users" },
    { id: "messages", label: "Messages", icon: "message" },
    { id: "contracts", label: "Contracts", icon: "contract" },
    { id: "analytics", label: "Analytics", icon: "analytics" },
    { id: "calendar", label: "Calendar", icon: "calendar" },
    { id: "settings", label: "Settings", icon: "settings" },
  ];
  const influencerNav = [
    { id: "dashboard", label: "Dashboard", icon: "dashboard" },
    { id: "opportunities", label: "Opportunities", icon: "megaphone" },
    { id: "collaborations", label: "Collaborations", icon: "users" },
    { id: "applications", label: "Applications", icon: "bookmark" },
    { id: "messages", label: "Messages", icon: "message" },
    { id: "portfolio", label: "Portfolio", icon: "portfolio" },
    { id: "analytics", label: "Analytics", icon: "analytics" },
    { id: "payments", label: "Payments", icon: "payment" },
    { id: "reviews", label: "Reviews", icon: "star" },
    { id: "settings", label: "Settings", icon: "settings" },
  ];
  const nav = role === "brand" ? brandNav : influencerNav;
  const displayName = role === "brand" ? "Zara Fashion" : "Ayla Rahman";

  const navItems = nav.map(item => {
    const active = page === item.id;
    return `
      <button data-action="setPage" data-value="${item.id}" style="width:100%;display:flex;align-items:center;gap:10px;padding:10px 10px;border-radius:12px;border:none;background:${active ? `linear-gradient(135deg, ${COLORS.accent}22, ${COLORS.lavender}22)` : "transparent"};color:${active ? COLORS.accent : COLORS.textMuted};font-weight:${active ? 600 : 400};font-size:13px;cursor:pointer;margin-bottom:2px;transition:all .15s;text-align:left;">
        ${Icon(item.icon, 17, active ? COLORS.accent : COLORS.textLight)}
        <span>${item.label}</span>
        ${active ? `<div style="margin-left:auto;width:6px;height:6px;border-radius:50%;background:${COLORS.accent};"></div>` : ""}
      </button>`;
  }).join("");

  return `
  <div style="width:220px;background:${COLORS.white};border-right:1px solid ${COLORS.border};display:flex;flex-direction:column;height:100vh;position:fixed;top:0;left:0;z-index:100;">
    <div style="padding:24px 20px 16px;">
      <div style="display:flex;align-items:center;gap:9px;">
        <div style="width:32px;height:32px;border-radius:10px;background:linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender});display:flex;align-items:center;justify-content:center;">
          ${Icon("globe", 16, "#fff")}
        </div>
        <span style="font-weight:700;font-size:16px;color:${COLORS.text};">Pressly</span>
      </div>
      <div style="margin-top:6px;font-size:11px;color:${COLORS.textMuted};background:#F3EEF9;border-radius:8px;padding:3px 8px;display:inline-block;font-weight:500;text-transform:uppercase;letter-spacing:0.5px;">
        ${role === "brand" ? "Brand" : "Influencer"}
      </div>
    </div>

    <nav style="flex:1;padding:8px 12px;overflow-y:auto;">
      ${navItems}
    </nav>

    <div style="padding:12px 12px 20px;">
      <div style="display:flex;align-items:center;gap:10px;padding:10px;border-radius:12px;background:${COLORS.bg};margin-bottom:4px;">
        ${Avatar({ name: displayName, size: 32 })}
        <div style="flex:1;min-width:0;">
          <div style="font-size:12px;font-weight:600;color:${COLORS.text};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${displayName}</div>
          <div style="font-size:10px;color:${COLORS.textMuted};">Pro plan</div>
        </div>
      </div>
      <button data-action="logout" style="width:100%;display:flex;align-items:center;gap:8px;padding:9px 10px;border-radius:12px;border:none;background:transparent;color:${COLORS.error};font-size:13px;cursor:pointer;">
        ${Icon("logout", 16, COLORS.error)} Sign out
      </button>
    </div>
  </div>`;
}

// --- TOPBAR ---
function Topbar(title) {
  return `
  <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 28px;background:${COLORS.white};border-bottom:1px solid ${COLORS.border};position:sticky;top:0;z-index:50;">
    <div style="font-size:18px;font-weight:700;color:${COLORS.text};">${title}</div>
    <div style="display:flex;align-items:center;gap:12px;">
      <div style="display:flex;align-items:center;gap:8px;background:${COLORS.bg};border-radius:12px;padding:8px 14px;border:1px solid ${COLORS.border};">
        ${Icon("search", 15, COLORS.textLight)}
        <input placeholder="Search..." style="border:none;background:transparent;outline:none;font-size:13px;color:${COLORS.text};width:160px;" />
      </div>
      <button style="position:relative;background:${COLORS.bg};border:1px solid ${COLORS.border};border-radius:10px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;cursor:pointer;">
        ${Icon("bell", 17, COLORS.textMuted)}
        <span style="position:absolute;top:6px;right:6px;width:8px;height:8px;border-radius:50%;background:${COLORS.error};border:2px solid ${COLORS.white};"></span>
      </button>
      ${Avatar({ name: "User", size: 36 })}
    </div>
  </div>`;
}
