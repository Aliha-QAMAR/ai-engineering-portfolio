// --- COLORS (kept in sync with static/css/style.css :root variables) ---
const COLORS = {
  lavender: "#BFA2DB",
  softPurple: "#CDB4DB",
  accent: "#8E7CC3",
  bg: "#FAF8FF",
  white: "#FFFFFF",
  text: "#2D2547",
  textMuted: "#7B6FA0",
  textLight: "#A99CC4",
  border: "#E8E0F5",
  cardShadow: "0 2px 16px rgba(143,124,195,0.10)",
  success: "#6DBF94",
  warning: "#F4A261",
  error: "#E07070",
  successBg: "#EBF9F2",
  warningBg: "#FEF3EA",
  errorBg: "#FCEAEA",
};

// Turn a JS style object into an inline CSS string, e.g. {fontSize:12} -> "font-size:12"
function sx(obj = {}) {
  return Object.entries(obj)
    .map(([k, v]) => `${k.replace(/[A-Z]/g, m => "-" + m.toLowerCase())}:${v}`)
    .join(";");
}

// Escapes a value for safe use inside an HTML attribute
function esc(v) {
  return String(v).replace(/"/g, "&quot;");
}

// --- SHARED COMPONENTS ---

function Badge({ label, color = COLORS.accent, bg = "#EDE8F9" }) {
  return `<span style="${sx({ background: bg, color, "font-size": "11px", "font-weight": 600, "border-radius": "20px", padding: "2px 10px", "letter-spacing": "0.3px" })}">${label}</span>`;
}

// action/value become data-action / data-value attributes consumed by the
// central event-delegation handler in app.js
function Btn({ label, variant = "primary", action = "", value = "", extraStyle = "", extraAttrs = "" }) {
  const variants = {
    primary: `background:linear-gradient(135deg, ${COLORS.accent}, ${COLORS.lavender});color:#fff;border:none;`,
    secondary: `background:${COLORS.white};color:${COLORS.accent};border:1.5px solid ${COLORS.border};`,
    ghost: `background:transparent;color:${COLORS.textMuted};border:none;`,
  };
  return `<button ${action ? `data-action="${action}"` : ""} ${value !== "" ? `data-value="${esc(value)}"` : ""} ${extraAttrs}
    style="${variants[variant]}padding:9px 20px;border-radius:12px;font-weight:500;font-size:13px;cursor:pointer;display:inline-flex;align-items:center;gap:6px;transition:all .2s;${extraStyle}">
    ${label}
  </button>`;
}

function StatCard({ label, value, sub, icon, color = COLORS.accent, bg = "#F0EBF9" }) {
  return `
  <div style="background:${COLORS.white};border-radius:18px;padding:20px 22px;box-shadow:${COLORS.cardShadow};display:flex;gap:14px;align-items:center;">
    <div style="width:46px;height:46px;border-radius:14px;background:${bg};display:flex;align-items:center;justify-content:center;flex-shrink:0;">
      ${Icon(icon, 22, color)}
    </div>
    <div>
      <div style="font-size:22px;font-weight:700;color:${COLORS.text};line-height:1;">${value}</div>
      <div style="font-size:12px;color:${COLORS.textMuted};margin-top:3px;">${label}</div>
      ${sub ? `<div style="font-size:11px;color:${COLORS.success};margin-top:2px;font-weight:500;">${sub}</div>` : ""}
    </div>
  </div>`;
}

function Avatar({ name, size = 36, color = COLORS.accent, bg = "#EDE8F9" }) {
  const initials = name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  return `<div style="width:${size}px;height:${size}px;border-radius:50%;background:${bg};color:${color};font-size:${size * 0.35}px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;">${initials}</div>`;
}

// Mini bar chart used on the influencer dashboard
function MiniChart(data, color = COLORS.accent) {
  const max = Math.max(...data);
  return `
  <div style="display:flex;align-items:flex-end;gap:4px;height:48px;">
    ${data.map((v, i) => `<div style="flex:1;background:${i === data.length - 1 ? color : color + "40"};border-radius:4px 4px 0 0;height:${(v / max) * 100}%;transition:height .5s;"></div>`).join("")}
  </div>`;
}
